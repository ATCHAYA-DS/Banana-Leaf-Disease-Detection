/**
 * Robust Banana Leaf Disease Detection - Core Client JavaScript
 * Handles:
 * 1. Image upload, drag-and-drop, and instant preview
 * 2. Analysis mode selection (Single leaf vs Whole plant)
 * 3. Multi-language switching (en, ta, hi, te, ml, kn)
 * 4. Voice Assistant with Web Speech Synthesis API
 * 5. Diagnostic visual tabs (Original, Preprocessed, Grad-CAM XAI)
 * 6. Mobile navigation
 */

let allTranslations = null;
let speechSynth = window.speechSynthesis;
let currentUtterance = null;
let isSpeaking = false;

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    initTranslations();
    initMobileNav();
    initDragAndDrop();
    initAnalysisProgress();
});

/* ==========================================================================
   Multi-Language Switching System
   ========================================================================== */
async function initTranslations() {
    try {
        const res = await fetch('/api/translations');
        if (res.ok) {
            allTranslations = await res.json();
        }
    } catch (e) {
        console.warn("Could not load translation dictionary via API:", e);
    }
}

function changeLanguage(selectedLang) {
    // Save to cookie (valid for 30 days)
    document.cookie = `app_lang=${selectedLang};path=/;max-age=${60 * 60 * 24 * 30}`;
    
    // Update hidden input on forms
    const langInput = document.getElementById('formLangInput');
    if (langInput) {
        langInput.value = selectedLang;
    }

    // Refresh page with language param to re-render all server-rendered text & templates
    const url = new URL(window.location.href);
    url.searchParams.set('lang', selectedLang);
    window.location.href = url.toString();
}

/* ==========================================================================
   Mode Selection (Single Leaf vs Whole Plant)
   ========================================================================== */
function updateModeSelection(mode) {
    const singleLabel = document.getElementById('modeSingleLabel');
    const wholeLabel = document.getElementById('modeWholeLabel');

    if (mode === 'single_leaf') {
        if (singleLabel) singleLabel.classList.add('active');
        if (wholeLabel) wholeLabel.classList.remove('active');
    } else {
        if (wholeLabel) wholeLabel.classList.add('active');
        if (singleLabel) singleLabel.classList.remove('active');
    }
}

/* ==========================================================================
   Image Drag & Drop and Preview Handlers
   ========================================================================== */
function initDragAndDrop() {
    const dropZone = document.getElementById('dropZone');
    if (!dropZone) return;

    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, (e) => {
            e.preventDefault();
            e.stopPropagation();
            dropZone.classList.add('dragover');
        }, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, (e) => {
            e.preventDefault();
            e.stopPropagation();
            dropZone.classList.remove('dragover');
        }, false);
    });

    dropZone.addEventListener('drop', (e) => {
        const dt = e.dataTransfer;
        const files = dt.files;
        if (files && files.length > 0) {
            const fileInput = document.getElementById('fileInput');
            fileInput.files = files;
            handleFileSelect(files);
        }
    }, false);
}

function handleFileSelect(files) {
    if (!files || files.length === 0) return;
    const file = files[0];

    const validTypes = ['image/jpeg', 'image/jpg', 'image/png'];
    if (!validTypes.includes(file.type)) {
        alert("Please upload a valid image file (JPG, JPEG, or PNG).");
        return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
        const previewContainer = document.getElementById('previewContainer');
        const dropContent = document.getElementById('dropContent');
        const imagePreview = document.getElementById('imagePreview');
        const previewFilename = document.getElementById('previewFilename');
        const submitBtn = document.getElementById('submitBtn');

        if (imagePreview) imagePreview.src = e.target.result;
        if (previewFilename) previewFilename.textContent = file.name;
        if (dropContent) dropContent.style.display = 'none';
        if (previewContainer) previewContainer.style.display = 'block';
        if (submitBtn) submitBtn.disabled = false;
    };
    reader.readAsDataURL(file);
}

function clearSelectedImage(event) {
    if (event) event.stopPropagation();

    const fileInput = document.getElementById('fileInput');
    const previewContainer = document.getElementById('previewContainer');
    const dropContent = document.getElementById('dropContent');
    const imagePreview = document.getElementById('imagePreview');
    const submitBtn = document.getElementById('submitBtn');

    if (fileInput) fileInput.value = '';
    if (imagePreview) imagePreview.src = '';
    if (previewContainer) previewContainer.style.display = 'none';
    if (dropContent) dropContent.style.display = 'block';
    if (submitBtn) submitBtn.disabled = true;
}

/* ==========================================================================
   Analyzing Animation Steps
   ========================================================================== */
function initAnalysisProgress() {
    const form = document.getElementById('diseaseForm');
    if (!form) return;

    form.addEventListener('submit', () => {
        const overlay = document.getElementById('analyzingOverlay');
        const stepText = document.getElementById('analyzingStepText');
        if (overlay) overlay.style.display = 'flex';

        const steps = [
            "1. Reducing camera noise using OpenCV Bilateral Filtering...",
            "2. Applying CLAHE illumination balance to remove harsh shadows & glare...",
            "3. Isolating leaf structures and checking disease symptoms...",
            "4. Generating Explainable AI (Grad-CAM) attention heatmap...",
            "5. Preparing farmer diagnostic advice & audio recommendations..."
        ];

        let idx = 0;
        const interval = setInterval(() => {
            idx++;
            if (idx < steps.length && stepText) {
                stepText.textContent = steps[idx];
            } else {
                clearInterval(interval);
            }
        }, 800);
    });
}

/* ==========================================================================
   Result Visual Tabs (Original, Preprocessed, Grad-CAM)
   ========================================================================== */
function switchVisualTab(targetTabId) {
    const tabBtns = document.querySelectorAll('.tab-btn');
    const panels = document.querySelectorAll('.visual-view-panel');

    tabBtns.forEach(btn => btn.classList.remove('active'));
    panels.forEach(panel => {
        panel.classList.remove('active');
        panel.style.display = 'none';
    });

    const activeBtn = Array.from(tabBtns).find(btn => btn.getAttribute('onclick').includes(targetTabId));
    if (activeBtn) activeBtn.classList.add('active');

    const targetPanel = document.getElementById(targetTabId);
    if (targetPanel) {
        targetPanel.classList.add('active');
        targetPanel.style.display = 'block';
    }
}

/* ==========================================================================
   Voice Assistant (Web Speech Synthesis API)
   ========================================================================== */
const LANG_VOICE_MAP = {
    'en': 'en-IN',
    'ta': 'ta-IN',
    'hi': 'hi-IN',
    'te': 'te-IN',
    'ml': 'ml-IN',
    'kn': 'kn-IN'
};

function toggleVoiceSpeech() {
    if (!('speechSynthesis' in window)) {
        alert("Sorry, your browser does not support speech synthesis voice playback.");
        return;
    }

    const voiceBtn = document.getElementById('voiceBtn');
    const voiceBtnText = document.getElementById('voiceBtnText');

    if (isSpeaking) {
        speechSynth.cancel();
        isSpeaking = false;
        if (voiceBtn) voiceBtn.classList.remove('speaking');
        if (voiceBtnText) voiceBtnText.textContent = getVoiceButtonLabel(false);
        return;
    }

    // Read payload from data attributes
    const payload = document.getElementById('speechPayload');
    if (!payload) return;

    const disease = payload.getAttribute('data-disease') || '';
    const status = payload.getAttribute('data-status') || '';
    const confidence = payload.getAttribute('data-confidence') || '';
    const explanation = payload.getAttribute('data-explanation') || '';
    const recommendations = payload.getAttribute('data-recommendations') || '';

    const currentLang = document.body.getAttribute('data-lang') || 'en';

    // Build natural speech text based on language
    let speechText = "";
    if (currentLang === 'ta') {
        speechText = `வாழை இலை நோய் கண்டறிதல் முடிவு. கண்டறியப்பட்ட நிலை: ${disease}. துல்லிய சதவீதம்: ${confidence} சதவீதம். நோயின் விளக்கம்: ${explanation}. விவசாயி பரிந்துரைகள்: ${recommendations}`;
    } else if (currentLang === 'hi') {
        speechText = `केले के पत्ते के रोग का निदान परिणाम। पहचानी गई स्थिति: ${disease}। सटीकता: ${confidence} प्रतिशत। विवरण: ${explanation}। किसान सलाह: ${recommendations}`;
    } else if (currentLang === 'te') {
        speechText = `అరటి ఆకు తెగులు నిర్ధారణ ఫలితం. గుర్తించిన స్థితి: ${disease}. ఖచ్చితత్వం: ${confidence} శాతం. వివరణ: ${explanation}. రైతు సూచనలు: ${recommendations}`;
    } else if (currentLang === 'ml') {
        speechText = `വാഴയില രോഗനിർണ്ണയ ഫലം. കണ്ടെത്തിയ രോഗം: ${disease}. കൃത്യത: ${confidence} ശതമാനം. വിവരണം: ${explanation}. പരിപാലന നിർദ്ദേശങ്ങൾ: ${recommendations}`;
    } else if (currentLang === 'kn') {
        speechText = `ಬಾಳೆ ಎಲೆ ರೋಗ ಪತ್ತೆ ಫಲಿತಾಂಶ. ಗುರುತಿಸಲಾದ ರೋಗ: ${disease}. ನಿಖರತೆ: ${confidence} ಶೇಕಡಾ. ವಿವರಣೆ: ${explanation}. ರೈತ ಸಲಹೆಗಳು: ${recommendations}`;
    } else {
        speechText = `Banana leaf disease diagnosis result. Identified condition: ${disease}. Diagnostic confidence: ${confidence} percent. Visual explanation: ${explanation}. Practical recommendations: ${recommendations}`;
    }

    speechSynth.cancel(); // Stop any pending speech
    currentUtterance = new SpeechSynthesisUtterance(speechText);
    currentUtterance.rate = 0.95; // Slightly slower for clarity in rural and agricultural settings
    currentUtterance.pitch = 1.0;

    // Select suitable voice
    const targetLangCode = LANG_VOICE_MAP[currentLang] || 'en-US';
    const voices = speechSynth.getVoices();
    const matchedVoice = voices.find(v => v.lang.replace('_', '-').startsWith(targetLangCode.split('-')[0])) ||
                         voices.find(v => v.lang.includes('IN') || v.lang.includes('en'));
    
    if (matchedVoice) {
        currentUtterance.voice = matchedVoice;
    }

    currentUtterance.onstart = () => {
        isSpeaking = true;
        if (voiceBtn) voiceBtn.classList.add('speaking');
        if (voiceBtnText) voiceBtnText.textContent = getVoiceButtonLabel(true);
    };

    currentUtterance.onend = () => {
        isSpeaking = false;
        if (voiceBtn) voiceBtn.classList.remove('speaking');
        if (voiceBtnText) voiceBtnText.textContent = getVoiceButtonLabel(false);
    };

    currentUtterance.onerror = (e) => {
        console.error("Speech synthesis error:", e);
        isSpeaking = false;
        if (voiceBtn) voiceBtn.classList.remove('speaking');
        if (voiceBtnText) voiceBtnText.textContent = getVoiceButtonLabel(false);
    };

    speechSynth.speak(currentUtterance);
}

function getVoiceButtonLabel(speaking) {
    const currentLang = document.body.getAttribute('data-lang') || 'en';
    const labels = {
        'en': speaking ? "Stop Voice" : "Listen to Diagnosis",
        'ta': speaking ? "குரலை நிறுத்தவும்" : "முடிவை தமிழில் கேட்கவும்",
        'hi': speaking ? "आवाज़ रोकें" : "आवाज़ में सुनें",
        'te': speaking ? "వాయిస్ ఆపండి" : "వాయిస్‌లో వినండి",
        'ml': speaking ? "ശബ്ദം നിർത്തുക" : "ശബ്ദത്തിൽ കേൾക്കുക",
        'kn': speaking ? "ಧ್ವನಿ ನಿಲ್ಲಿಸಿ" : "ಧ್ವನಿಯಲ್ಲಿ ಕೇಳಿ"
    };
    return labels[currentLang] || (speaking ? "Stop Voice" : "Listen to Diagnosis");
}

/* ==========================================================================
   Mobile Nav Toggle
   ========================================================================== */
function initMobileNav() {
    const toggle = document.getElementById('mobileNavToggle');
    const links = document.getElementById('navLinks');

    if (toggle && links) {
        toggle.addEventListener('click', () => {
            links.classList.toggle('show');
        });
    }
}
