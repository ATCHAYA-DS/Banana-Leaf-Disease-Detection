# CNN Model Instructions for Banana Leaf Disease Detection

## Where to Place the Trained Model
Place your trained Keras/TensorFlow model file directly in this folder:
```
model/banana_disease_model.h5
```
Or `.keras` format (TensorFlow 2.16+ format).

---

## Supported Classes (Must match output layer index)
- **Index 0**: `Healthy`
- **Index 1**: `Black Sigatoka`
- **Index 2**: `Yellow Sigatoka`
- **Index 3**: `Panama Disease`

---

## How It Works in This Application
1. When the Flask server starts (`python app.py`), it automatically checks for `model/banana_disease_model.h5`.
2. If `banana_disease_model.h5` is present and TensorFlow is installed:
   - The web app automatically switches to **CNN MODEL ACTIVE** mode.
   - Predictions run through the trained neural network.
   - Grad-CAM heatmaps are computed using genuine backpropagation gradients from the final convolutional layer.
3. If the model file is not present:
   - The web app runs safely in **DEMO MODE**.
   - It displays a prominent "DEMO MODE" badge on the UI and clearly informs users that results are simulated using computer vision heuristics for educational and demonstration purposes.

---

## How to Train Your Own CNN Model
You can use `train_model.py` located in the root directory to train on a banana leaf dataset (e.g. from Kaggle or PlantVillage).
Run:
```bash
python train_model.py --data_dir /path/to/banana_dataset
```
The script will train a MobileNetV2 transfer learning model and export `banana_disease_model.h5` into this folder automatically!
